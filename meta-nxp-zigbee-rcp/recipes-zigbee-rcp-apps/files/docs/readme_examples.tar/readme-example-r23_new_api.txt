    ZBOSS Zigbee software protocol stack

    Copyright (c) 2012-2020 DSR Corporation, Denver CO, USA.
    www.dsr-zboss.com
    www.dsr-corporation.com
    All rights reserved.

    Copyright 2024 NXP

    This is unpublished proprietary source code of DSR Corporation
    The copyright notice does not evidence any actual or intended
    publication of such source code.

    ZBOSS is a registered trademark of Data Storage Research LLC d/b/a DSR
    Corporation

    Commercial Usage
    Licensees holding valid DSR Commercial licenses may use
    this file in accordance with the DSR Commercial License
    Agreement provided with the Software or, alternatively, in accordance
    with the terms contained in a written agreement between you and
    DSR.


ZBOSS R23 New API application
==============================

This set of applications demonstrates R23 New API sample
The set contains four applications:

  - Zigbee Coordinator (R23 New API ZC)
  - Zigbee Router  (R23 New API ZR)
  - Zigbee Router  (R22 API ZR)
  - Zigbee End Device  (R23 New API ZED)

The application set structure
------------------------------

 - Makefile
 - r23_zc.c  - *R23 coordinator application*
 - r22_zr.c  - *R22 router application*
 - r23_zr.c  - *R23 router application*
 - r23_zed.c - *R23 end device application*
 - r23_applications_common.h - *Common definitions for R23 new API sample app*
 - readme.txt - *This file*
 - test_readme.txt - *Expected outcomes*

  Application behavior
-----------------------
This application demonstrates the usage of R23 New API detailed in the test_readme.txt file

